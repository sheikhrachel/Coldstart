# python_setup.py
# import click


# create python development
def python_setup():
    pass
