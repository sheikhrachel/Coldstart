# create_environment.py
# import click
# from python_setup import python_setup


# Navigate to correct setup script based on language
def create_environment():
    pass


# Determine which language to setup environment in
def determine_language():
    pass


# Handle incorrect inputs for determine_language()
def determine_language_no_prompt():
    pass


# Handle init git repo for project from user provided git remote
def init_git(url: str):
    pass
