# Coldstart.py
from logo import present_logo
#from create_environment import language_validation


# main class to orchestrate scripts in order
def main():
    present_logo()
    #language_validation()


if __name__ == "__main__":
    main()
