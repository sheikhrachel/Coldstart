# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['scripts']

package_data = \
{'': ['*']}

install_requires = \
['black>=19.10b0,<20.0',
 'click>=7.0,<8.0',
 'flake8>=3.7.9,<4.0.0',
 'pre-commit>=2.0.1,<3.0.0']

setup_kwargs = {
    'name': 'coldstart',
    'version': '0.0.1',
    'description': 'Coldstart is a Python cli tool built with click to quickly create a development environment for your next project',
    'long_description': None,
    'author': 'Isaac Sheikh',
    'author_email': 'sheikhisaac@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.6',
}


setup(**setup_kwargs)
